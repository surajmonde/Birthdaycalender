import { Component } from '@angular/core';
import { SampleserviceService } from './sampleservice.service';
import Character from './Character';
import 'rxjs/Rx';
//import { Observable } from 'rxjs/Rx';
import { Observable, of } from 'rxjs';
import 'rxjs/add/operator/map';
import { map } from 'rxjs/operators';
//import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { RouterModule, Routes,Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [SampleserviceService]
})
export class AppComponent {
  title = 'angulardata';
    // variable declare
    //books: restaurants[];

  //public samplelist;
  //constructor(private sampleservice: SampleserviceService,public router: Router) {}

  //ngOnInit() {
  //  this.sampleservice.getrestouruntlist().subscribe(
    //  res => {

//        this.samplelist = res;
        //console.log(this.samplelist);
 //     },
   //   err => {
     //   console.log('Something went wrong');
     // }
   // );
 // }

public openChangePasswordForm(){
alert('Hellow');
}

 
}
