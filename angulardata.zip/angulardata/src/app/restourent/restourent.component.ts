import { Component, OnInit } from '@angular/core';
import { SampleserviceService } from '../sampleservice.service';
import Character from '../Character';
import 'rxjs/Rx';
//import { Observable } from 'rxjs/Rx';
import { Observable, of } from 'rxjs';
import 'rxjs/add/operator/map';
import { map } from 'rxjs/operators';
//import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { RouterModule, Routes,Router } from '@angular/router';
//import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-restourent',
  templateUrl: './restourent.component.html',
  styleUrls: ['./restourent.component.css']
})
export class RestourentComponent implements OnInit {

  constructor(private sampleservice: SampleserviceService,public router: Router) { }
  public samplelist;
  filteredArray: any[] = []

  defaultRecords: any = 5;
  ngOnInit() {
    this.sampleservice.getrestouruntlist().subscribe(
      res => {

        this.samplelist = res;
        //console.log(this.samplelist);
      },
      err => {
        console.log('Something went wrong');
      }
    );
  }
  onPaginateChange(data) {
    this.filteredArray = this.samplelist.slice(0, data.pageSize);
  }
}
