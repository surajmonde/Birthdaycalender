import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestourentComponent } from './restourent.component';

describe('RestourentComponent', () => {
  let component: RestourentComponent;
  let fixture: ComponentFixture<RestourentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestourentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestourentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
