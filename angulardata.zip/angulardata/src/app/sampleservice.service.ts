import { Injectable } from '@angular/core';
import { Http, RequestOptions, Response, ResponseContentType } from '@angular/http';
//import 'rxjs';

//import { Observable } from 'rxjs/Rx';
import { shareReplay } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SampleserviceService {

  constructor(private http: HttpClient) { }

  getrestouruntlist(){
    return this
    .http
    .get(`http://opentable.herokuapp.com/api/restaurants?city=toronto`);

  }

}
