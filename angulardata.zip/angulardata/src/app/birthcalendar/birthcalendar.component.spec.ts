import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BirthcalendarComponent } from './birthcalendar.component';

describe('BirthcalendarComponent', () => {
  let component: BirthcalendarComponent;
  let fixture: ComponentFixture<BirthcalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BirthcalendarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BirthcalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
