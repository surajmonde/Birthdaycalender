import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FavouriteComponent } from './favourite/favourite.component';
import { Routes, RouterModule } from '@angular/router';
import { RestourentComponent } from './restourent/restourent.component';
import { BirthcalendarComponent } from './birthcalendar/birthcalendar.component';
const routes: Routes = [
//  {path: "",  component: RestourentComponent, pathMatch: "full"},
   {path: "",  component: BirthcalendarComponent, pathMatch: "full"},
  { path: 'favourite-component', component: FavouriteComponent },
  { path: 'restourent-component', component: RestourentComponent }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ]
 // declarations: []
})
export class AppRoutingModule { }
